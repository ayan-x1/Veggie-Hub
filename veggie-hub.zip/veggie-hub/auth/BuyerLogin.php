<?php
session_start();

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Buyer Login - VeggieHub</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            min-height: 100vh;
            background: url('https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=1920') center/cover fixed;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            width: 100%;
            max-width: 400px;
            overflow: hidden;
        }

        .card-header {
            background: #292b2c;
            padding: 20px;
            color: goldenrod;
            font-size: 1.25rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card-header i {
            font-size: 1.1em;
        }

        .card-body {
            padding: 30px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #666;
            margin-bottom: 8px;
            font-weight: 400;
        }

        .form-group label i {
            color: goldenrod;
            transform: scaleX(-1);
        }

        .form-control {
            background: white;
            border: 1px solid #e1e1e1;
            border-radius: 8px;
            padding: 12px 15px;
            height: auto;
            font-size: 0.95rem;
            width: 100%;
        }

        .form-control:focus {
            border-color: #ddd;
            box-shadow: none;
            outline: none;
        }

        .form-control::placeholder {
            color: #999;
        }

        .btn-login {
            background: #292b2c;
            color: goldenrod;
            border: none;
            border-radius: 8px;
            padding: 12px;
            font-weight: 500;
            width: 100%;
            margin-top: 10px;
            font-size: 0.95rem;
        }

        .btn-login:hover {
            background: #1a1a1a;
            color: goldenrod;
        }

        .login-footer {
            text-align: center;
            margin-top: 25px;
        }

        .login-footer a {
            color: #666;
            text-decoration: none;
            display: block;
            margin: 8px 0;
            font-size: 0.9rem;
        }

        .login-footer a:hover {
            color: #292b2c;
        }

        .login-footer i {
            margin-right: 6px;
            color: #666;
        }
    </style>
</head>

<body>
    <div class="login-card">
        <div class="card-header">
            <i class="fas fa-user-circle"></i>
            Login to VeggieHub
        </div>
        <div class="card-body">
            <form action="BuyerLogin.php" method="post">
                <div class="form-group">
                    <label><i class="fas fa-phone"></i>Phone Number</label>
                    <input type="text" class="form-control" name="phonenumber" placeholder="Enter your phone number" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i>Password</label>
                    <input type="password" class="form-control" name="password" placeholder="Enter your password" required>
                </div>
                <button type="submit" class="btn btn-login" name="login">Login</button>
                <div class="login-footer">
                    <a href="BuyerForgotPassword.php">
                        <i class="fas fa-key"></i>Forgot your password?
                    </a>
                    <a href="BuyerRegistration.php">
                        <i class="fas fa-user-plus"></i>Create New Account
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>

</html>

<?php
include("../Includes/db.php");

if (isset($_POST['login'])) {
    $phonenumber = mysqli_real_escape_string($con, $_POST['phonenumber']);
    $password = mysqli_real_escape_string($con, $_POST['password']);

    $ciphering = "AES-128-CTR";
    $iv_length = openssl_cipher_iv_length($ciphering);
    $options = 0;
    $encryption_iv = '2345678910111211';
    $encryption_key = "DE";

    $encryption = openssl_encrypt(
        $password,
        $ciphering,
        $encryption_key,
        $options,
        $encryption_iv
    );

    $query = "select * from buyerregistration where buyer_phone = '$phonenumber' and buyer_password = '$encryption'";
    $run_query = mysqli_query($con, $query);
    $count_rows = mysqli_num_rows($run_query);
    if ($count_rows == 0) {
        echo "<script>alert('Please Enter Valid Details');</script>";
        echo "<script>window.open('BuyerLogin.php','_self')</script>";
    }
    while ($row = mysqli_fetch_array($run_query)) {
        $id = $row['buyer_id'];
    }

    $_SESSION['phonenumber'] = $phonenumber;
    echo "<script>window.open('../BuyerPortal2/bhome.php','_self')</script>";
}

?>