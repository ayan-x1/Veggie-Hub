<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reset Password - VeggieHub</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            min-height: 100vh;
            background: url('https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=1920') center/cover fixed;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .reset-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            width: 100%;
            max-width: 400px;
            overflow: hidden;
        }

        .card-header {
            background: #292b2c;
            padding: 20px;
            color: goldenrod;
            font-size: 1.25rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card-header i {
            font-size: 1.1em;
        }

        .card-body {
            padding: 30px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #666;
            margin-bottom: 8px;
            font-weight: 400;
        }

        .form-group label i {
            color: goldenrod;
            transform: scaleX(-1);
        }

        .form-control {
            background: white;
            border: 1px solid #e1e1e1;
            border-radius: 8px;
            padding: 12px 15px;
            height: auto;
            font-size: 0.95rem;
            width: 100%;
        }

        .form-control:focus {
            border-color: #ddd;
            box-shadow: none;
            outline: none;
        }

        .form-control::placeholder {
            color: #999;
        }

        .btn-reset {
            background: #292b2c;
            color: goldenrod;
            border: none;
            border-radius: 8px;
            padding: 12px;
            font-weight: 500;
            width: 100%;
            margin-top: 10px;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-reset:hover {
            background: #1a1a1a;
            color: goldenrod;
        }

        .reset-footer {
            text-align: center;
            margin-top: 25px;
        }

        .reset-footer a {
            color: #666;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-size: 0.9rem;
        }

        .reset-footer a:hover {
            color: #292b2c;
        }

        .reset-footer i {
            color: #666;
        }
    </style>
</head>
<body>
    <div class="reset-card">
        <div class="card-header">
            <i class="fas fa-key"></i>
            Reset Password
        </div>
        <div class="card-body">
            <form action="FarmerForgotPassword.php" method="post">
                <div class="form-group">
                    <label><i class="fas fa-phone"></i>Phone Number</label>
                    <input type="text" class="form-control" name="phonenumber" placeholder="Enter your phone number" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-id-card"></i>PAN Number</label>
                    <input type="text" class="form-control" name="pan" placeholder="Enter your PAN number" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i>New Password</label>
                    <input type="password" class="form-control" name="password" placeholder="Enter new password" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i>Confirm Password</label>
                    <input type="password" class="form-control" name="confirmpassword" placeholder="Confirm new password" required>
                </div>
                <button type="submit" class="btn btn-reset" name="register">
                    <i class="fas fa-sync-alt"></i>Update Password
                </button>
                <div class="reset-footer">
                    <a href="FarmerLogin.php">
                        <i class="fas fa-arrow-left"></i>Back to Login
                    </a>
                </div>
            </form>
        </div>
    </div>

    <?php
    include("../Includes/db.php");
    if (isset($_POST['register'])) {
        $phonenumber = mysqli_real_escape_string($con, $_POST['phonenumber']);
        $pan = mysqli_real_escape_string($con, $_POST['pan']);
        $password = mysqli_real_escape_string($con, $_POST['password']);
        $confirmpassword = mysqli_real_escape_string($con, $_POST['confirmpassword']);

        $query = "select * from farmerregistration where farmer_phone = '$phonenumber' and farmer_pan = '$pan'";
        $run_query = mysqli_query($con, $query);
        $count_rows = mysqli_num_rows($run_query);

        $ciphering = "AES-128-CTR";
        $iv_length = openssl_cipher_iv_length($ciphering);
        $options = 0;
        $encryption_iv = '2345678910111211';
        $encryption_key = "DE";

        $encryption = openssl_encrypt(
            $password,
            $ciphering,
            $encryption_key,
            $options,
            $encryption_iv
        );

        if (strcmp($password, $confirmpassword) == 0) {
            if ($count_rows != 0) {
                $update_query = "update farmerregistration set farmer_password = '$encryption' 
                                     where farmer_phone = '$phonenumber' and farmer_pan = '$pan' ";

                $run_query = mysqli_query($con, $update_query);

                echo "<script>alert('Password Updated Successfully');</script>";
                echo "<script>window.open('FarmerLogin.php','_self')</script>";
            } else if ($count_rows == 0) {
                echo "<script>alert('Please Enter Valid Details');</script>";
            }
        } else {
            echo "<script>alert('Please Enter Valid Details');</script>";
        }
    }
    ?>
</body>
</html>