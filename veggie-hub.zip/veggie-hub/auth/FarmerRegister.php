<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://kit.fontawesome.com/c587fc1763.js" crossorigin="anonymous"></script>
    <title>Farmer Registration Portal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="../portal_files/bootstrap.min.css">
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Define all districts for each state as a global object
        const stateDistricts = {
            'MAHARASHTRA': ['Mumbai', 'Pune', 'Nagpur', 'Thane', 'Nashik', 'Aurangabad', 'Solapur', 'Amravati', 'Kolhapur', 'Sangli'],
            'ANDHRA PRADESH': ['Visakhapatnam', 'Vijayawada', 'Guntur', 'Nellore', 'Kurnool', 'Rajahmundry', 'Tirupati', 'Kakinada', 'Kadapa', 'Anantapur'],
            'ASSAM': ['Guwahati', 'Silchar', 'Dibrugarh', 'Jorhat', 'Nagaon', 'Tinsukia', 'Tezpur', 'Karimganj', 'Sivasagar', 'Goalpara'],
            'BIHAR': ['Patna', 'Gaya', 'Bhagalpur', 'Muzaffarpur', 'Darbhanga', 'Purnia', 'Arrah', 'Begusarai', 'Katihar', 'Chapra'],
            'GUJARAT': ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Bhavnagar', 'Jamnagar', 'Junagadh', 'Gandhinagar', 'Anand', 'Bharuch'],
            'HARYANA': ['Faridabad', 'Gurgaon', 'Panipat', 'Ambala', 'Yamunanagar', 'Rohtak', 'Hisar', 'Karnal', 'Sonipat', 'Panchkula'],
            'HIMACHAL PRADESH': ['Shimla', 'Kullu', 'Mandi', 'Solan', 'Dharamshala', 'Bilaspur', 'Una', 'Hamirpur', 'Chamba', 'Kangra'],
            'JAMMU AND KASHMIR': ['Srinagar', 'Jammu', 'Anantnag', 'Baramulla', 'Kathua', 'Pulwama', 'Udhampur', 'Budgam', 'Kupwara', 'Rajouri'],
            'KARNATAKA': ['Bangalore', 'Mysore', 'Hubli', 'Mangalore', 'Belgaum', 'Gulbarga', 'Davanagere', 'Bellary', 'Bijapur', 'Shimoga'],
            'KERALA': ['Thiruvananthapuram', 'Kochi', 'Kozhikode', 'Thrissur', 'Kollam', 'Alappuzha', 'Palakkad', 'Malappuram', 'Kannur', 'Kottayam'],
            'MADHYA PRADESH': ['Bhopal', 'Indore', 'Jabalpur', 'Gwalior', 'Ujjain', 'Sagar', 'Dewas', 'Satna', 'Ratlam', 'Rewa'],
            'TAMIL NADU': ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem', 'Tirunelveli', 'Tiruppur', 'Erode', 'Vellore', 'Thoothukudi'],
            'PUDUCHERRY': ['Puducherry', 'Karaikal', 'Mahe', 'Yanam'],
            'LAKSHADWEEP': ['Kavaratti', 'Agatti', 'Amini', 'Andrott', 'Kadmat', 'Kalpeni', 'Kiltan', 'Minicoy'],
            'GOA': ['North Goa', 'South Goa'],
            'DADRA AND NAGAR HAVELI': ['Dadra', 'Nagar Haveli'],
            'DAMAN AND DIU': ['Daman', 'Diu'],
            'CHHATTISGARH': ['Raipur', 'Bhilai', 'Bilaspur', 'Durg', 'Korba', 'Rajnandgaon', 'Raigarh', 'Jagdalpur', 'Ambikapur', 'Dhamtari'],
            'JHARKAND': ['Ranchi', 'Jamshedpur', 'Dhanbad', 'Bokaro', 'Deoghar', 'Hazaribagh', 'Giridih', 'Dumka', 'Palamu', 'Hazaribagh'],
            'WEST BENGAL': ['Kolkata', 'Howrah', 'Durgapur', 'Asansol', 'Siliguri', 'Bardhaman', 'Malda', 'Kharagpur', 'Haldia', 'Darjeeling'],
            'MEGHALAYA': ['Shillong', 'Tura', 'Jowai', 'Nongstoin', 'Williamnagar', 'Baghmara', 'Nongpoh', 'Mairang'],
            'SIKKIM': ['Gangtok', 'Namchi', 'Mangan', 'Gyalshing'],
            'UTTAR PRADESH': ['Lucknow', 'Kanpur', 'Agra', 'Varanasi', 'Meerut', 'Allahabad', 'Ghaziabad', 'Noida', 'Bareilly', 'Aligarh'],
            'RAJASTHAN': ['Jaipur', 'Jodhpur', 'Kota', 'Bikaner', 'Ajmer', 'Udaipur', 'Bhilwara', 'Alwar', 'Bharatpur', 'Sri Ganganagar'],
            'PUNJAB': ['Ludhiana', 'Amritsar', 'Jalandhar', 'Patiala', 'Bathinda', 'Pathankot', 'Mohali', 'Hoshiarpur', 'Moga', 'Ferozepur'],
            'NAGALAND': ['Kohima', 'Dimapur', 'Mokokchung', 'Tuensang', 'Wokha', 'Zunheboto', 'Phek', 'Mon'],
            'TRIPURA': ['Agartala', 'Udaipur', 'Dharmanagar', 'Kailasahar', 'Belonia', 'Khowai', 'Teliamura'],
            'MIZORAM': ['Aizawl', 'Lunglei', 'Saiha', 'Champhai', 'Kolasib', 'Serchhip', 'Lawngtlai'],
            'ARUNACHAL PRADESH': ['Itanagar', 'Tawang', 'Bomdila', 'Ziro', 'Along', 'Pasighat', 'Tezu', 'Anini'],
            'CHANDIGARH': ['Chandigarh'],
            'DELHI': ['New Delhi', 'Central Delhi', 'East Delhi', 'North Delhi', 'North East Delhi', 'North West Delhi', 'South Delhi', 'South West Delhi', 'West Delhi']
        };

        // Function to update districts when state changes
        function updateDistricts() {
            var stateSelect = document.getElementById('states');
            var districtSelect = document.getElementById('district');
            var selectedState = stateSelect.value;
            
            // Clear existing options
            districtSelect.innerHTML = '<option value="">Select District</option>';
            
            // If no state is selected, return
            if (!selectedState) {
                return;
            }
            
            // Get districts for the selected state
            var districts = stateDistricts[selectedState] || [];
            
            // Add districts to dropdown
            districts.forEach(function(district) {
                var option = document.createElement('option');
                option.value = district;
                option.textContent = district;
                districtSelect.appendChild(option);
            });
        }

        // Initialize when document is ready
        $(document).ready(function() {
            // Set up event listener for state change
            $('#states').on('change', updateDistricts);
            
            // Form validation
            $('form[name="my-form"]').on('submit', function(e) {
                var password = $('#password').val();
                var confirmPassword = $('#confirm_password').val();
                var stateSelected = $('#states').val();
                var districtSelected = $('#district').val();
                
                // Validate password match
                if (password !== confirmPassword) {
                    alert('Password and Confirm Password should match');
                    e.preventDefault();
                    return false;
                }
                
                // Validate district selection if state is selected
                if (stateSelected && !districtSelected) {
                    alert('Please select a district for the chosen state');
                    e.preventDefault();
                    return false;
                }
            });
            
            // Debug info
            console.log('Script loaded. Districts data initialized.');
        });
    </script>
    <style>
        @import url(https://fonts.googleapis.com/css?family=Raleway:300,400,600);
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-size: .9rem;
            font-weight: 400;
            line-height: 1.6;
            color: #212529;
            text-align: left;
            background-color: #f5f8fa;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, rgba(76, 175, 80, 0.1) 0%, rgba(0, 0, 0, 0.8) 100%), url('https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=1920');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            padding: 40px 0;
            min-height: 100vh;
        }

        .card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border: none;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            background-color: #292b2c !important;
            border-bottom: 2px solid goldenrod;
            padding: 20px;
        }

        .card-header h4 {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 600;
            color: goldenrod;
        }

        .card-body {
            padding: 30px;
            border: none !important;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .col-form-label {
            font-size: 0.95rem;
            color: #333;
            font-weight: 500;
        }

        .form-control {
            border-radius: 8px;
            padding: 12px;
            border: 1px solid rgba(0, 0, 0, 0.1) !important;
            background: rgba(255, 255, 255, 0.9);
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
        }

        .form-control:focus {
            box-shadow: 0 0 0 3px rgba(218, 165, 32, 0.2);
            border-color: goldenrod !important;
        }

        select.form-control {
            height: auto;
            padding: 12px;
            cursor: pointer;
        }

        textarea.form-control {
            min-height: 100px;
        }

        .btn-primary {
            background: linear-gradient(45deg, #292b2c, #444) !important;
            border: none !important;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            color: goldenrod !important;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            background: linear-gradient(45deg, #444, #292b2c) !important;
        }

        /* Form Sections */
        .form-section {
            position: relative;
            padding-top: 20px;
            margin-top: 30px;
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }

        .form-section:first-child {
            border-top: none;
            margin-top: 0;
            padding-top: 0;
        }

        .form-section-title {
            font-size: 1.1rem;
            color: #292b2c;
            margin-bottom: 20px;
            font-weight: 600;
        }

        /* Icon Styling */
        .fas, .far {
            color: goldenrod;
            width: 20px;
            text-align: center;
            margin-right: 8px;
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .card-body {
                padding: 20px;
            }

            .col-form-label {
                text-align: left !important;
                margin-bottom: 5px;
            }

            .form-group {
                margin-bottom: 20px;
            }
        }

        /* Existing styles remain unchanged */
        .myfooter {
            background-color: #292b2c;
            color: goldenrod;
            margin-top: 15px;
        }

        .aligncenter {
            text-align: center;
        }

        a {
            color: goldenrod;
        }

        nav {
            background-color: #292b2c;
        }

        .navbar-custom {
            background-color: #292b2c;
        }

        .navbar-custom .navbar-brand,
        .navbar-custom .navbar-text {
            background-color: #292b2c;
        }

        .navbar-custom .navbar-nav .nav-link {
            background-color: #292b2c;
        }

        .navbar-custom .nav-item.active .nav-link,
        .navbar-custom .nav-item:hover .nav-link {
            background-color: #292b2c;
        }
    </style>
</head>

<body>
    <main class="my-form">
        <div class="cotainer">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h4><i class="fas fa-user-plus"></i> Register as a Farmer</h4>
                        </div>
                        <div class="card-body">
                            <form name="my-form" action="FarmerRegister.php" method="post">
                                <!-- Personal Information Section -->
                                <div class="form-section">
                                    <div class="form-section-title"><i class="fas fa-user"></i> Personal Information</div>
                                    <div class="form-group row">
                                        <label for="full_name" class="col-md-4 col-form-label text-md-right"><i class="fas fa-user mr-2"></i>Full Name</label>
                                        <div class="col-md-6">
                                            <input type="text" id="full_name" class="form-control" name="name" placeholder="Enter Your Name" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="phone_number" class="col-md-4 col-form-label text-md-right"><i class="fas fa-phone-alt mr-2"></i>Phone Number</label>
                                        <div class="col-md-6">
                                            <input type="text" id="phone_number" class="form-control" name="phone" placeholder="Phone Number" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="email_address" class="col-md-4 col-form-label text-md-right"><i class="far fa-envelope mr-2"></i>Email Address</label>
                                        <div class="col-md-6">
                                            <input type="email" id="email_address" class="form-control" name="email" placeholder="Email Address" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row">
                                        <label for="address" class="col-md-4 col-form-label text-md-right"><i class="fas fa-home mr-2"></i>Address</label>
                                        <div class="col-md-6">
                                            <textarea id="address" class="form-control" name="address" placeholder="Enter Your Address" required></textarea>
                                        </div>
                                    </div>
                                </div>

                                <!-- Location Information Section -->
                                <div class="form-section">
                                    <div class="form-section-title"><i class="fas fa-map-marker-alt"></i> Location Details</div>
                                    <div class="form-group row">
                                        <label for="states" class="col-md-4 col-form-label text-md-right"><i class="fas fa-map mr-2"></i>State</label>
                                        <div class="col-md-6">
                                            <select id="states" class="form-control" name="state" required>
                                                <option value="">Select State</option>
                                                <option value="MAHARASHTRA">MAHARASHTRA</option>
                                                <option value="ANDHRA PRADESH">ANDHRA PRADESH</option>
                                                <option value="ASSAM">ASSAM</option>
                                                <option value="BIHAR">BIHAR</option>
                                                <option value="GUJARAT">GUJARAT</option>
                                                <option value="HARYANA">HARYANA</option>
                                                <option value="HIMACHAL PRADESH">HIMACHAL PRADESH</option>
                                                <option value="JAMMU AND KASHMIR">JAMMU AND KASHMIR</option>
                                                <option value="KARNATAKA">KARNATAKA</option>
                                                <option value="KERALA">KERALA</option>
                                                <option value="MADHYA PRADESH">MADHYA PRADESH</option>
                                                <option value="TAMIL NADU">TAMIL NADU</option>
                                                <option value="PUDUCHERRY">PUDUCHERRY</option>
                                                <option value="LAKSHADWEEP">LAKSHADWEEP</option>
                                                <option value="GOA">GOA</option>
                                                <option value="DADRA AND NAGAR HAVELI">DADRA AND NAGAR HAVELI</option>
                                                <option value="DAMAN AND DIU">DAMAN AND DIU</option>
                                                <option value="CHHATTISGARH">CHHATTISGARH</option>
                                                <option value="JHARKAND">JHARKAND</option>
                                                <option value="WEST BENGAL">WEST BENGAL</option>
                                                <option value="MEGHALAYA">MEGHALAYA</option>
                                                <option value="SIKKIM">SIKKIM</option>
                                                <option value="UTTAR PRADESH">UTTAR PRADESH</option>
                                                <option value="RAJASTHAN">RAJASTHAN</option>
                                                <option value="PUNJAB">PUNJAB</option>
                                                <option value="NAGALAND">NAGALAND</option>
                                                <option value="TRIPURA">TRIPURA</option>
                                                <option value="MIZORAM">MIZORAM</option>
                                                <option value="ARUNACHAL PRADESH">ARUNACHAL PRADESH</option>
                                                <option value="CHANDIGARH">CHANDIGARH</option>
                                                <option value="DELHI">DELHI</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="district" class="col-md-4 col-form-label text-md-right"><i class="fas fa-city mr-2"></i>District</label>
                                        <div class="col-md-6">
                                            <select id="district" name="district" class="form-control" required>
                                                <option value="">Select District</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <!-- Account Security Section -->
                                <div class="form-section">
                                    <div class="form-section-title"><i class="fas fa-lock"></i> Account Security</div>
                                    <div class="form-group row">
                                        <label for="pan" class="col-md-4 col-form-label text-md-right"><i class="fas fa-id-card mr-2"></i>PAN Number</label>
                                        <div class="col-md-6">
                                            <input type="text" id="pan" class="form-control" name="pan" placeholder="PAN Number" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="account" class="col-md-4 col-form-label text-md-right"><i class="fas fa-university mr-2"></i>Bank Account</label>
                                        <div class="col-md-6">
                                            <input type="text" id="account" class="form-control" name="account" placeholder="Bank Account Number" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="password" class="col-md-4 col-form-label text-md-right"><i class="fas fa-key mr-2"></i>Password</label>
                                        <div class="col-md-6">
                                            <input type="password" id="password" class="form-control" name="password" placeholder="Password" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="confirm_password" class="col-md-4 col-form-label text-md-right"><i class="fas fa-lock mr-2"></i>Confirm Password</label>
                                        <div class="col-md-6">
                                            <input type="password" id="confirm_password" class="form-control" name="confirmpassword" placeholder="Confirm Password" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row mb-0">
                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary" name="register" value="Register">
                                            <i class="fas fa-check-circle"></i> Complete Registration
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>

</html>

<?php

include("../Includes/db.php");

$ciphering = "AES-128-CTR";
$iv_length = openssl_cipher_iv_length($ciphering);
$options = 0;
$encryption_iv = '2345678910111211';
$encryption_key = "DE";

if (isset($_POST['register'])) {
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $address = mysqli_real_escape_string($con, $_POST['address']);
    $pan = mysqli_real_escape_string($con, $_POST['pan']);
    $account = mysqli_real_escape_string($con, $_POST['account']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $confirmpassword = mysqli_real_escape_string($con, $_POST['confirmpassword']);
    $district = mysqli_real_escape_string($con, $_POST['district']);
    $state = mysqli_real_escape_string($con, $_POST['state']);

    $encryption = openssl_encrypt(
        $password,
        $ciphering,
        $encryption_key,
        $options,
        $encryption_iv
    );

    if (strcmp($password, $confirmpassword) == 0) {
        $query = "INSERT INTO farmerregistration (farmer_name, farmer_phone, farmer_email,
                farmer_address, farmer_state, farmer_district,
                farmer_pan, farmer_bank, farmer_password) 
                VALUES ('$name', '$phone', '$email', '$address',
                '$state', '$district', '$pan', '$account',
                '$encryption')";

        $run_register_query = mysqli_query($con, $query);
        if ($run_register_query) {
            echo "<script>alert('Registration Successful!');</script>";
            echo "<script>window.open('FarmerLogin.php','_self')</script>";
        } else {
            echo "<script>alert('Error: " . mysqli_error($con) . "');</script>";
        }
    } else {
        echo "<script>
                alert('Password and Confirm Password Should be same');
            </script>";
    }
}

?>