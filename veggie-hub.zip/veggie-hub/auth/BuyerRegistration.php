<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" type="text/css" href="../Styles/buyer_reg.css">
	<script src="https://kit.fontawesome.com/c587fc1763.js" crossorigin="anonymous"></script>
	<title>Buyer Registration - VeggieHub</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="../portal_files/bootstrap.min.css">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	<style>
	@import url(https://fonts.googleapis.com/css?family=Raleway:300,400,600);
	.myfooter {
        background-color: #292b2c;
        color: goldenrod;
        margin-top: 15px;
    }

    .aligncenter {
        text-align: center;
    }

    a {
        color: goldenrod;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    nav {
        background-color: #292b2c;
    }

    .navbar-custom {
        background-color: #292b2c;
    }

    /* change the brand and text color */
    .navbar-custom .navbar-brand,
    .navbar-custom .navbar-text {
        background-color: #292b2c;
    }

    .navbar-custom .navbar-nav .nav-link {
        background-color: #292b2c;
    }

    .navbar-custom .nav-item.active .nav-link,
    .navbar-custom .nav-item:hover .nav-link {
        background-color: #292b2c;
    }

    .mybtn {
        border-color: green;
        border-style: solid;
    }

    .right {
        display: flex;
    }

    .left {
        display: none;
    }

    .cart {
        margin-right: -9px;
    }

    .profile {
        margin-right: 2px;
    }

    .login {
        margin-right: -2px;
        margin-top: 12px;
        display: none;
    }

    .searchbox {
        width: 60%;
    }

    .lists {
        display: inline-block;
    }

    .moblists {
        display: none;
    }

    .logins {
        text-align: center;
        margin-right: -30%;
        margin-left: 35%;
    }

    body {
        margin: 0;
        font-size: .9rem;
        font-weight: 400;
        line-height: 1.6;
        color: #212529;
        text-align: left;
        background-color: #f5f8fa;
        width: 100%;
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(135deg, rgba(76, 175, 80, 0.1) 0%, rgba(0, 0, 0, 0.8) 100%), url('https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=1920');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        padding: 40px 0;
        min-height: 100vh;
    }

    .my-form, .login-form
    {
        font-family:  sans-serif;
    }

    .my-form
    {
        padding-top: 1.5rem;
        padding-bottom: 1.5rem;
    }

    .my-form .row
    {
        margin-left: 0;
        margin-right: 0;
    }

    .login-form
    {
        padding-top: 1.5rem;
        padding-bottom: 1.5rem;
    }

    .login-form .row
    {
        margin-left: 0;
        margin-right: 0;
    }
	@media only screen and (min-device-width:320px) and (max-device-width:480px) {
        /* .mycarousel {
            display: none;
        }

        .firstimage {
            height: auto;
            width: 90%;
        }

        .card {
            width: 80%;
            margin-left: 10%;
            margin-right: 10%;

        }

        .col {
            margin-top: 20px;
        } */

        .right {
            display: none;
            background-color: #ff5500;
        }

        /* 
            .settings{
            margin-left:79%;
        } */
        .left {
            display: flex;
        }

        .moblogo {
            display: none;
        }

        .logins {
            text-align: center;
            margin-right: 35%;
            padding: 15px;
        }

        .searchbox {
            width: 95%;
            margin-right: 5%;
            margin-left: 0%;
        }

        .moblists {
            display: inline-block;
            text-align: center;
            width: 100%;
        }
        /* .pic{
        height:auto;
    } */
    
    /* .mobtext{
        display:none;
    }
    .destext{
        display:inline-block;
        width:90%;
        margin-left: 5%;
        margin-right: 5%;
    } */
    }

    /* New Welcome Header Styles */
    .welcome-header {
        text-align: center;
        color: white;
        margin-bottom: 40px;
        position: relative;
        z-index: 1;
    }

    .welcome-header h1 {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 15px;
        color: white;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }

    .welcome-header p {
        font-size: 1.1rem;
        opacity: 0.9;
        max-width: 600px;
        margin: 0 auto;
        line-height: 1.6;
    }

    .logo-icon {
        font-size: 3rem;
        color: goldenrod;
        margin-bottom: 20px;
        animation: float 3s ease-in-out infinite;
    }

    @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
    }

    .benefits-list {
        display: flex;
        justify-content: center;
        gap: 30px;
        margin-top: 25px;
        flex-wrap: wrap;
    }

    .benefit-item {
        display: flex;
        align-items: center;
        gap: 10px;
        background: rgba(255, 255, 255, 0.1);
        padding: 10px 20px;
        border-radius: 50px;
        backdrop-filter: blur(5px);
    }

    .benefit-item i {
        color: goldenrod;
    }

    @media (max-width: 768px) {
        .welcome-header h1 {
            font-size: 2rem;
        }

        .welcome-header p {
            font-size: 1rem;
            padding: 0 20px;
        }

        .benefits-list {
            flex-direction: column;
            align-items: center;
            gap: 15px;
        }
    }

    .card {
        background: rgba(255, 255, 255, 0.9);
        backdrop-filter: blur(10px);
        border: none;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        transition: transform 0.3s ease;
    }

    .card:hover {
        transform: translateY(-5px);
    }

    .card-header {
            background-color: #292b2c !important;
            border-bottom: 2px solid goldenrod;
            padding: 20px;
        }

        .card-header h4 {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 600;
            color: goldenrod;
        }

    .card-body {
        padding: 30px;
        border: none !important;
    }

    .form-group {
        margin-bottom: 25px;
    }

    .col-form-label {
        font-size: 0.95rem;
        color: #333;
    }

    .form-control {
        border-radius: 8px;
        padding: 12px;
        border: 1px solid rgba(0, 0, 0, 0.1) !important;
        background: rgba(255, 255, 255, 0.9);
        transition: all 0.3s ease;
    }

    .form-control:focus {
        box-shadow: 0 0 0 3px rgba(218, 165, 32, 0.2);
        border-color: goldenrod !important;
    }

    textarea.form-control {
        min-height: 100px;
    }

    .btn-primary {
        background: linear-gradient(45deg, #292b2c, #444) !important;
        border: none !important;
        padding: 12px 30px;
        border-radius: 8px;
        font-weight: 600;
        letter-spacing: 0.5px;
        transition: all 0.3s ease;
    }

    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        background: linear-gradient(45deg, #444, #292b2c) !important;
    }

    /* Section Dividers */
    .form-section {
        position: relative;
        padding-top: 20px;
        margin-top: 30px;
        border-top: 1px solid rgba(0, 0, 0, 0.1);
    }

    .form-section:first-child {
        border-top: none;
        margin-top: 0;
        padding-top: 0;
    }

    .form-section-title {
        font-size: 1.1rem;
        color: #292b2c;
        margin-bottom: 20px;
        font-weight: 600;
    }

    /* Icon Styling */
    .fas, .far {
        color: goldenrod;
        width: 20px;
        text-align: center;
        margin-right: 8px;
    }

    /* Responsive Adjustments */
    @media (max-width: 768px) {
        .card-body {
            padding: 20px;
        }

        .col-form-label {
            text-align: left !important;
            margin-bottom: 5px;
        }

        .form-group {
            margin-bottom: 20px;
        }
    }
    </style>
</head>

<body>
    <main class="my-form">
        <div class="cotainer">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h4><i class="fas fa-user-plus"></i> Register as a Buyer</h4>
                        </div>
                        <div class="card-body">
                            <form name="my-form" action="BuyerRegistration.php" method="post">
                                <!-- Personal Information Section -->
                                <div class="form-section">
                                    <div class="form-section-title">Personal Information</div>
                                    <div class="form-group row">
                                        <label for="full_name" class="col-md-4 col-form-label text-md-right"><i class="fas fa-user mr-2"></i><b>Full Name</b></label>
                                        <div class="col-md-6">
                                            <input type="text" id="full_name" class="form-control border border-dark" name="name" placeholder="Enter Your Name" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="phone_number" class="col-md-4 col-form-label text-md-right "><i class="fas fa-phone-alt mr-2"></i><b>Phone Number</b></label>
                                        <div class="col-md-6">
                                            <input type="text" id="phone_number" class="form-control w-100 border border-dark" style="width:100% ! important;" name="phonenumber" placeholder="Phone Number" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row">
                                        <label for="email_address" class="col-md-4 col-form-label text-md-right"><i class="far fa-envelope mr-2"></i><b>E-Mail Address</b></label>
                                        <div class="col-md-6">
                                            <input type="email" id="email_address" class="form-control border border-dark" name="mail" placeholder="E-Mail ID" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="present_address" class="col-md-4 col-form-label text-md-right"><i class="fas fa-home mr-2"></i><b>Present Address</b></label>
                                        <div class="col-md-6">
                                            <textarea type="text" id="present_address" class="form-control border border-dark" rows="4" name="address" placeholder="Address" required></textarea>
                                        </div>
                                    </div>
                                </div>

                                <!-- Business Information Section -->
                                <div class="form-section">
                                    <div class="form-section-title">Business Information</div>
                                    <div class="form-group row">
                                        <label for="campany_name" class="col-md-4 col-form-label text-md-right"><i class="fas fa-building mr-2"></i><b>Company Name</b></label>
                                        <div class="col-md-6">
                                            <input type="text" id="campany_name" class="form-control border border-dark" name="company_name" placeholder="Company name" required>
                                        </div>
                                    </div>			

                                    <div class="form-group row">
                                        <label for="lisence" class="col-md-4 col-form-label text-md-right"><i class="fas fa-id-badge mr-2"></i><b>Lisence</b></label>
                                        <div class="col-md-6">
                                            <input type="text" id="lisence" class="form-control border border-dark" name="license" placeholder="license" required>
                                        </div>
                                    </div>
                                </div>

                                <!-- Financial Information Section -->
                                <div class="form-section">
                                    <div class="form-section-title">Financial Information</div>
                                    <div class="form-group row">
                                        <label for="account1" class="col-md-4 col-form-label text-md-right"><i class="fas fa-university mr-2"></i><b>Bank Account No.</b></label>
                                        <div class="col-md-6">
                                            <input type="text" id="account1" class="form-control border border-dark" name="account" placeholder="Bank Account number" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="account2" class="col-md-4 col-form-label text-md-right"><i class="fas fa-pencil-alt mr-2"></i><b>PAN No.</b></label>
                                        <div class="col-md-6">
                                            <input type="text" id="account2" class="form-control border border-dark" name="pan" placeholder="Pan number" required>
                                        </div>
                                    </div>
                                </div>

                                <!-- Account Security Section -->
                                <div class="form-section">
                                    <div class="form-section-title">Account Security</div>
                                    <div class="form-group row">
                                        <label for="user_name" class="col-md-4 col-form-label text-md-right"><i class="fas fa-user mr-2"></i><b>User Name</b></label>
                                        <div class="col-md-6">
                                            <input type="text" id="user_name" class="form-control border border-dark" name="username" placeholder="Username" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="p1" class="col-md-4 col-form-label text-md-right "><i class="fas fa-lock mr-2"></i><b>Password</b></label>
                                        <div class="col-md-6">
                                            <input id="p1" class="form-control border border-dark" type="password" name="password" placeholder="Password" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="p2" class="col-md-4 col-form-label text-md-right"><i class="fas fa-lock mr-2"></i><b>Confirm Password</b></label>
                                        <div class="col-md-6">
                                            <input id="p2" class="form-control border border-dark" type="password" name="confirmpassword" placeholder="Confirm Password" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary" name="register" value="Register">
                                            <i class="fas fa-check-circle"></i> Complete Registration
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>

</html>


<?php

include("../Includes/db.php");

if (isset($_POST['register'])) {

	$name = mysqli_real_escape_string($con, $_POST['name']);
	$phonenumber = mysqli_real_escape_string($con, $_POST['phonenumber']);
	$address = mysqli_real_escape_string($con, $_POST['address']);
	$company_name = mysqli_real_escape_string($con, $_POST['company_name']);
	$license = mysqli_real_escape_string($con, $_POST['license']);
	$account = mysqli_real_escape_string($con, $_POST['account']);
	$pan = mysqli_real_escape_string($con, $_POST['pan']);
	$mail = mysqli_real_escape_string($con, $_POST['mail']);
	$username = mysqli_real_escape_string($con, $_POST['username']);
	$password = mysqli_real_escape_string($con, $_POST['password']);
	$confirmpassword = mysqli_real_escape_string($con, $_POST['confirmpassword']);

	$ciphering = "AES-128-CTR";
	$iv_length = openssl_cipher_iv_length($ciphering);
	$options = 0;
	$encryption_iv = '2345678910111211';
	$encryption_key = "DE";

	$encryption = openssl_encrypt(
		$password,
		$ciphering,
		$encryption_key,
		$options,
		$encryption_iv
	);

	if (strcmp($password, $confirmpassword) == 0) {

		$query = "insert into buyerregistration (buyer_name,buyer_phone,buyer_addr,buyer_comp,
		buyer_license,buyer_bank,buyer_pan,buyer_mail,buyer_username,buyer_password) 
		values ('$name','$phonenumber','$address','$company_name','$license','$account','$pan',
		'$mail','$username','$encryption')";

		$run_register_query = mysqli_query($con, $query);
		echo "<script>alert('SucessFully Inserted');</script>";
		echo "<script>window.open('BuyerLogin.php','_self')</script>";
	} else if (strcmp($password, $confirmpassword) != 0) {
		echo "<script>
			alert('Password and Confirm Password Should be same');
		</script>";
	}
}


?>