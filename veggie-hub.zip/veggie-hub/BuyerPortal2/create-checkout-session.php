<?php
session_start();
require_once('stripe-php-master/init.php'); // Make sure the Stripe PHP SDK is in this folder

\Stripe\Stripe::setApiKey('sk_test_51RAor02c4fOC6zPuBhbiFvFGYjyI3XJdfPvlRVrEfpwMAh3G3zYldbBDqx5hJMiyygGGXnehquoXoVPGlO51iZZB00PGGqsrgF'); // Replace with your Secret Key

$session = \Stripe\Checkout\Session::create([
    'payment_method_types' => ['card'],
    'line_items' => [[
        'price_data' => [
            'currency' => 'inr',
            'product_data' => [
                'name' => 'Farm Fresh Vegetables',
            ],
            'unit_amount' => 5000, // ₹50.00 (5000 paisa)
        ],
        'quantity' => 1,
    ]],
    'mode' => 'payment',
    'success_url' => 'http://localhost/VeggieHub/BuyerPortal2/Success.php',
    'cancel_url' => 'http://localhost/VeggieHub/BuyerPortal2/cancel.php',
]);

echo json_encode(['id' => $session->id]);
?>
