<?php
session_start();
include("../Includes/db.php");

if(isset($_SESSION['phonenumber'])) {
    $phone = $_SESSION['phonenumber'];
    
    // Delete all items from save for later for this user
    $query = "DELETE FROM saveforlater WHERE buyer_phone = '$phone'";
    $result = mysqli_query($con, $query);
    
    if($result) {
        echo "success";
    } else {
        echo "error";
    }
}
?> 