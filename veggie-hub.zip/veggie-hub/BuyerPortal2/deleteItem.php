<?php
session_start();
include("../Includes/db.php");

if(isset($_SESSION['phonenumber']) && isset($_POST['item_id'])) {
    $phone = $_SESSION['phonenumber'];
    $item_id = $_POST['item_id'];
    
    // Delete specific item from save for later
    $query = "DELETE FROM saveforlater WHERE buyer_phone = '$phone' AND id = '$item_id'";
    $result = mysqli_query($con, $query);
    
    if($result) {
        echo "success";
    } else {
        echo "error";
    }
}
?> 