<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "impulse101");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get farmer ID from query string
$farmer_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch farmer info
$sql = "SELECT * FROM farmerregistration WHERE farmer_id = $farmer_id";
$result = mysqli_query($conn, $sql);
$farmer = mysqli_fetch_assoc($result);

if (!$farmer) {
    echo "Farmer not found.";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Farmer Profile</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 40px;
        }
        .profile-card {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            text-align: center;
        }
        .profile-image {
            width: 130px;
            height: 130px;
            background: #e6f5e6;
            border: 4px solid #4CAF50;
            border-radius: 50%;
            margin: 0 auto 20px;
            background-image: url('../Images/Homepage/farmer.png'); /* ✅ Updated Image */
            background-size: cover;
            background-position: center;
        }
        h2 {
            margin: 0 0 5px;
        }
        
        .location {
            color: #777;
            font-size: 16px;
        }
        .details {
            margin-top: 30px;
            text-align: left;
        }
        .details p {
            font-size: 16px;
            margin: 10px 0;
        }
        .label {
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="profile-card">
    <div class="profile-image"></div>
    <h2><?= htmlspecialchars($farmer['farmer_name']) ?></h2>
    <div class="location">
        <?= htmlspecialchars($farmer['farmer_district']) ?>, <?= htmlspecialchars($farmer['farmer_state']) ?>
    </div>

    <div class="details">
        <p><span class="label">Phone:</span> <?= htmlspecialchars($farmer['farmer_phone']) ?></p>
        <p><span class="label">Address:</span>
            <?= $farmer['farmer_address'] ? htmlspecialchars($farmer['farmer_address']) : "No address provided." ?>
        </p>
        <p><span class="label">About Farmer:</span> This farmer hasn't added a bio yet.</p>
    </div>
</div>

</body>
</html>