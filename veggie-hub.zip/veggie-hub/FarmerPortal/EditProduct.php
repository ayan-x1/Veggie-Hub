<?php
     include("../Functions/functions.php");
     ?>

<?php
$conn = new mysqli("localhost", "root", "", "impulse101");

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM products WHERE product_id = $id";
    $result = $conn->query($sql);
    $product = $result->fetch_assoc();
}

if (isset($_POST['update'])) {
    $title = $_POST['title'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $delivery = $_POST['delivery'];
    $desc = $_POST['desc'];

    $sql = "UPDATE products SET 
        product_title = '$title', 
        product_price = '$price', 
        product_stock = '$stock', 
        product_delivery = '$delivery', 
        product_desc = '$desc' 
        WHERE product_id = $id";

    if ($conn->query($sql)) {
        echo "<script>alert('Product updated successfully'); window.location.href='FarmerProductDetails.php?id=$id';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <style>
        body {
            background-color: #fff;
            font-family: Arial, sans-serif;
            margin: 0;
        }
        .header {
            background-color: #1c1c1c;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 28px;
        }
        .container {
            width: 60%;
            margin: 40px auto;
            background-color: #222;
            color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.5);
        }
        .container h2 {
            text-align: center;
            color: #ffcc00;
            margin-bottom: 30px;
        }
        label {
            display: block;
            margin: 10px 0 6px;
            color: #ccc;
        }
        input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            border: none;
            margin-bottom: 20px;
            font-size: 16px;
        }
        textarea {
            height: 80px;
            resize: vertical;
        }
        .btn {
            padding: 12px 25px;
            background-color: #ffcc00;
            color: #000;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
            transition: background 0.3s;
        }
        .btn:hover {
            background-color: #e6b800;
        }
        .center {
            text-align: center;
        }
    </style>
</head>
<body>

<div class="header">
    VeggieHub - Edit Product
</div>

<div class="container">
    <h2>Update Product Information</h2>
    <form method="post">
        <label>Product Title:</label>
        <input type="text" name="title" value="<?= $product['product_title'] ?>" required>

        <label>Price (per Kg):</label>
        <input type="number" name="price" value="<?= $product['product_price'] ?>" required>

        <label>Stock (Kgs):</label>
        <input type="number" name="stock" value="<?= $product['product_stock'] ?>" required>

        <label>Delivery:</label>
        <input type="text" name="delivery" value="<?= $product['product_delivery'] ?>" required>

        <label>Description:</label>
        <textarea name="desc"><?= $product['product_desc'] ?></textarea>

        <div class="center">
            <button type="submit" name="update" class="btn">Update Product</button>
        </div>
    </form>
</div>

</body>
</html>